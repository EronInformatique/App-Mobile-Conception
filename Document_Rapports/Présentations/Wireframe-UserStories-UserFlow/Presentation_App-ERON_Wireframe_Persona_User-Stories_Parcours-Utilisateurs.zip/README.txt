1. Ouvrir d'abord le fichier "Presentation_Persona-UserStories-Userflow.pdf"
Dans ce fichier vous trouverez 2 personas , les users stories associés à ces personas et les parcours utilisateurs associés aux users stories (voir définition ci dessous):
- Les personas sont les cibles utilisateurs de l'application. Ils représentent les profils type des futurs utilisateurs de l'application
- Les users stories sont basés sur le modèle "En tant que 'persona' je souhaite ... afin de ..." . Ces users stories permettent de bien définir les besoins des utilisateurs concernant l'application à développer
- Les parcours utilisateurs correspondent aux chemins entre les différents écrans de l'applications, parcouru par l'utilisateur, correspondant aux User Stories. 


2. Ouvrir les parcours utilisateurs au format pdf et cliquer sur les ellipses rouges pour aller d'un écran à l'autre et effectué le parcours utilisateur correspondant. 

**(PENSEZ à ADAPTER la taille du PDF à votre écran dans les configurations de votre lecteur PDF pour pouvoir voir les wireframe/écrans de smartphone dans son ensemble)**

**(Vous pouvez également voir les parcours utilisateurs en une seule image avec les fichiers png)**
